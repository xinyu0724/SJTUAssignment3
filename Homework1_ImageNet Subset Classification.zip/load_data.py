import os
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import numpy as np
from torchvision import transforms


class ImageNetData(Dataset):
    def __init__(self, path, transforms=None):
        super(ImageNetData).__init__()
        self.path = path
        self.label_list = os.listdir(self.path)
        self.img_list = []
        for x in self.label_list:
            self.img_list += os.listdir(os.path.join(self.path, x))
        self.every_label_num = len(self.img_list) // len(self.label_list)
        self.transforms = transforms
        # 原来参数为self, root_dir, label_dir
        # self.root_dir = root_dir
        # self.label_dir = label_dir
        # self.path = os.path.join(self.root_dir, self.label_dir)
        # self.img_path = os.listdir(self.path)

    def __getitem__(self, index):
        label_path = self.label_list[index // self.every_label_num]
        img_path = os.path.join(self.path, label_path, self.img_list[index])
        img = Image.open(img_path).convert('RGB')
        if self.transforms:
            img = self.transforms(img)
        label = index // self.every_label_num
        array = np.asarray(img)
        data = torch.tensor(array)
        return data, label
        # img_name = self.img_path[index]
        # img_item_path = os.path.join(self.root_dir, self.label_dir, img_name)
        # pil_img = Image.open(img_item_path)
        # array = np.asarray(pil_img)
        # img_data = torch.tensor(array)
        # label = self.label_dir
        # return img_data, label

    def __len__(self):
        return len(self.img_list)

def load_data(batch_size=128, num_workers=0, _data_dir='./data'):
    transform_train = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])
    ])

    transform_test = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    train_set = ImageNetData(os.path.join(_data_dir, 'train'), transforms=transform_train)
    train_loader = DataLoader(train_set, batch_size, shuffle=True, num_workers=num_workers, pin_memory=True)
    test_set = ImageNetData(os.path.join(_data_dir, 'val'),transforms=transform_test)
    test_loader = DataLoader(test_set, batch_size, shuffle=True, num_workers=num_workers, pin_memory=True)

    return train_set, train_loader, test_set, test_loader

batch_size = 32
_data_dir = 'data'

train_set = ImageNetData(os.path.join(_data_dir, 'train'))
train_loader = DataLoader(train_set, batch_size, shuffle=True, num_workers=0, pin_memory=True)
test_set = ImageNetData(os.path.join(_data_dir, 'val'))
test_loader = DataLoader(test_set, batch_size, shuffle=True, num_workers=0, pin_memory=True)


# choose one number you like
myseed = 200107
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
np.random.seed(myseed)
torch.manual_seed(myseed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(myseed)



