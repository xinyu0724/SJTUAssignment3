import os
import torch
import torch.nn as nn
from torch import optim
from tqdm import tqdm
from resnet18 import ResNet18
from load_data import load_data
from torch.utils.tensorboard import SummaryWriter
import matplotlib.pyplot as plt


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# number of epoch
n_epoch = 30
# number of batch_size
batch_size = 128
# learning rate
lr = 0.01

# train data and test data
train_data, train_loader, test_data, test_loader = load_data(batch_size=batch_size, num_workers=0, _data_dir='data')
flag_x = len(test_data)
# ResNet18 model
model = ResNet18().to(device)

# Define loss function to multi-classification
criterion = nn.CrossEntropyLoss()
# optimizer method
optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
writer = SummaryWriter('./logs')

best_acc = 0

if __name__ == "__main__":
    if not os.path.isdir('./models'):
        os.mkdir('./models')
    plot_train_loss = []
    plot_train_acc = []
    print("Start Training. Model : ResNet-18")
    for epoch in range(n_epoch):
        model.train()

        train_losses = []
        train_accs = []

        for batch_img in tqdm(train_loader):
            # get a batch data : images and their labels
            images, labels = batch_img
            # The prediction of the batch data input
            predictor = model(images.to(device))
            # calculate the loss
            loss = criterion(predictor, labels.to(device))
            # Gradients stored in the previous step should be cleared out
            optimizer.zero_grad()
            # Compute the gradient for parameters
            loss.backward()
            # Update the parameters
            optimizer.step()

            train_losses.append(loss.item())

            pred = predictor.argmax(dim=1)

            correct_num = torch.eq(pred.to(device), labels.to(device)).sum().float().item()

            train_accs.append(correct_num / len(labels))

        #print(f"Train Epoch: {epoch + 1}/{n_epoch}\t Batch Train Loss:{loss.item()}\t Acc: {correct_num / len(labels)}")
        train_loss = sum(train_losses) / len(train_losses)
        plot_train_loss.append(train_loss)
        writer.add_scalar(tag="Train_loss", scalar_value=train_loss, global_step=epoch)
        train_acc = sum(train_accs) / len(train_accs)
        plot_train_acc.append(train_acc)
        writer.add_scalar(tag="Train_accuracy", scalar_value=train_acc, global_step=epoch)

        print(f"Train Epoch: {epoch + 1}/{n_epoch}\t Train Loss: {train_loss : .5f}\t, Acc: {train_acc : .5f}")

        if train_acc > best_acc:
            best_acc = train_acc
            torch.save(obj=model.state_dict(), f='models/model.ckpt')

    model_best = ResNet18().to(device)
    model_best.load_state_dict(torch.load("models/model.ckpt"))
    model_best.eval()
    correct_top1 = 0.0
    correct_top5 = 0.0
    with torch.no_grad():
        for img_test in tqdm(test_loader):
            '''
            a batch of images and their labels
            test_imgs: a batch images,  real_labels: a batch images' labels
            '''
            test_imgs, real_labels = img_test
            # The prediction of model and the input are some images
            pred_out = model_best(test_imgs.to(device))

            pred_top1 = pred_out.argmax(dim=1)
            correct_top1 += torch.eq(pred_top1.to(device), real_labels.to(device)).sum().float().item()

            real_top5 = real_labels.reshape(len(real_labels), 1)
            _, pred_top5 = pred_out.topk(5, dim=1, largest=True, sorted=True)
            correct_top5 += torch.eq(pred_top5.to(device), real_top5.to(device)).sum().float().item()
    print(f"Top1 accuracy: {correct_top1 / len(test_data)}\t Top5 accuracy: {correct_top5 / len(test_data)}")

    # x = list(range(1, n_epoch + 1))
    # plt.figure(1)
    # plt.plot(x, plot_train_loss)
    # plt.xticks(range(0, n_epoch + 1, 5))
    # plt.show()
    #
    # plt.figure(2)
    # plt.plot(x, plot_train_acc)
    # plt.xticks(range(0, n_epoch + 1, 5))
    # plt.show()

